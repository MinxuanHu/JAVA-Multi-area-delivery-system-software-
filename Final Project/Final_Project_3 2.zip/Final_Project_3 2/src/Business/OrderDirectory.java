/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class OrderDirectory {
    private ArrayList<Order> orderDir;
    public OrderDirectory() {
        orderDir = new ArrayList();
    }

    public ArrayList<Order> getOrderDir() {
        return orderDir;
    }

    public void setOrderDir(ArrayList<Order> orderDir) {
        this.orderDir = orderDir;
    }
    
}
