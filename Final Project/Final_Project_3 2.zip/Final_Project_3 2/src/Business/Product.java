/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Enterprise.Enterprise;
import javax.swing.ImageIcon;

/**
 *
 * @author sunyan
 */
public class Product {
    private String Shop;
    private ImageIcon image;
    private String name;
    private String description;
    private LabelDirectory labels;
    private float evaluation;
    private int saleNum;
    private int quantity;
    private float price;
    private Enterprise shopen;
    private CommentDirectory comments;
    private int id;
    private static int count = 1;

    public Product() {
        this.comments=new CommentDirectory();
        this.labels=new LabelDirectory();
        id = count;
        count++;
    }

    public Enterprise getShopen() {
        return shopen;
    }

    public void setShopen(Enterprise shopen) {
        this.shopen = shopen;
    }

    

    public String getShop() {
        return Shop;
    }

    public void setShop(String Shop) {
        this.Shop = Shop;
    }

    
    public ImageIcon getImage() {
        return image;
    }

    public void setImage(ImageIcon image) {
        this.image = image;
    }

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LabelDirectory getLabels() {
        return labels;
    }

    public void setLabels(LabelDirectory labels) {
        this.labels = labels;
    }

    

    public float getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(float evaluation) {
        this.evaluation = evaluation;
    }

    public int getSaleNum() {
        return saleNum;
    }

    public void setSaleNum(int saleNum) {
        this.saleNum = saleNum;
    }

    public CommentDirectory getComments() {
        return comments;
    }

    public void setComments(CommentDirectory comments) {
        this.comments = comments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    @Override
    public String toString() {
        return name;
    }
}
