/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class AddressDirectory {
    private ArrayList<Address> addressList;

    public AddressDirectory() {
        addressList = new ArrayList();
    }

    public ArrayList<Address> getAddressList() {
        return addressList;
    }

    public void setAddressList(ArrayList<Address> addressList) {
        this.addressList = addressList;
    }
    public Address createAddress(String name,String streetAddress,String aptAddress,String teleNum,String zipCode,String City){
        Address address = new Address();
        address.setAddressName(name);
        address.setStreetAddress(streetAddress);
        address.setAptAddress(aptAddress);
        address.setTeleNum(teleNum);
        address.setZipCode(zipCode);
        address.setCity(City);
        addressList.add(address);
        return address;
    }
}
