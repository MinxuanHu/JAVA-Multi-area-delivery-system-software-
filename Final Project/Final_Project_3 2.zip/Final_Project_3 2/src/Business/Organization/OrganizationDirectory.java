    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Organization.Type type){
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.Rider.getValue())){
            organization = new RiderOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.ShopManager.getValue())){
            organization = new ShopManagerOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.OrderManager.getValue())){
            organization = new OrderOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.KitchenAdmin.getValue())){
            organization = new KitchenOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.CustomerServe.getValue())){
            organization = new CustomerServeOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.ShopConnect.getValue())){
            organization = new ShopConnectOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
}
