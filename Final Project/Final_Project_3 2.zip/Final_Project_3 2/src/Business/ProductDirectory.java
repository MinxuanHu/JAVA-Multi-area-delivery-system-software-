/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author sunyan
 */
public class ProductDirectory {
    private ArrayList<Product> productList;
    public ProductDirectory() {
        productList = new ArrayList();
    }

    public ArrayList<Product> getProductDir() {
        return productList;
    }

    public Product createProduct(ImageIcon image,String name,String description,float eva,int soldNum,float price){
        Product p = new Product();
        p.setName(name);
        p.setImage(image);
        p.setDescription(description);
        
        p.setEvaluation(eva);
        p.setSaleNum(soldNum);
        p.setPrice(price);
        productList.add(p);
        return p;
    }
}
